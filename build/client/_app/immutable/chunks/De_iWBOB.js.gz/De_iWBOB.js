import{K as a}from"./XKlFPWCa.js";a();
